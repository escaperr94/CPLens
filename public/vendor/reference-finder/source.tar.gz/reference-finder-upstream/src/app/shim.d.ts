declare module "*.scss" {
	const styles: object;
	export default styles;
}

declare module "*.css" {
	const styles: object;
	export default styles;
}
