import { useTranslation } from "react-i18next";
import { useRef } from "react";
import "bootstrap/js/dist/dropdown";

import { ElementType, LineStyle, PointStyle, useDB, useSettings, useStore } from "../store";
import { StepComponent } from "./step";
import { Diagram } from "./svg/diagram";
import { Exact } from "./exact";
import { resetWorker } from "../bridge";
import { ExportButton } from "./export/exportButton";
import { formatSolution } from "./formatSolution";

import type { LineElement, PointElement, Solution } from "../store";

interface SolutionComponentProps {
	data: Solution;
	show: boolean;
	onSelect: () => void;
}

interface AddButtonProps {
	data: Solution;
}

const DIAGRAM_ZOOM = 1.15;
const DIAGRAM_PADDING = 0.18;
const DIAGRAM_SIZE = `${12 * DIAGRAM_ZOOM}rem`;

/**
 * Function that runs when the user accepts a specific solution.
 * Adds the creases from the last diagram of the accepted solution and recreates the database.
 */
function addAsExistingCreases(data: Solution) {
	gtag("event", "ref_add_existing_refs");

	// Add the creases from the last diagram of the accepted solution to the store (to render on the preview paper)
	const { existingMarks, existingLines, existingRefs } = useStore.getState();
	for(let i = 0; i < data.steps.length; i++) {
		let step = data.steps[i];
		const diag = data.diagrams[i];
		if(step.axiom != 0) { // line
			const lookFor = step.pinch ? LineStyle.pinch : LineStyle.valley;
			const el = diag.find(e =>
				e && e.type == ElementType.line && e.style == lookFor
			) as LineElement | undefined;
			if(el) {
				el.style = LineStyle.crease;
				existingRefs.push(el);
				if(!step.pinch) existingLines.push([el.from, el.to]);
			}
			if(step.intersection) step = step.intersection; // continue with the next part
		}
		if(step.axiom == 0) { // point
			const el = diag.find(e =>
				e && e.type == ElementType.point && e.style == PointStyle.action
			) as PointElement | undefined;
			if(el) {
				el.style = PointStyle.normal;
				existingRefs.push(el);
				existingMarks.push(el.pt);
			}
		}
	}
	useStore.setState({
		existingRefs, existingMarks, existingLines, // Add the existing marks and lines to the store
		solutions: [], // Empty out the list of solutions so the user notices that the input mark/line is solved
	});

	// Recreate the database
	resetWorker(useDB.getState());
}

function AddButton({ data }: AddButtonProps) {
	const { t } = useTranslation();
	return (
		<button type="button" className="btn btn-success py-0" onClick={() => addAsExistingCreases(data)}>
			<i className="fa-solid fa-circle-plus"></i>
			<span className="d-inline-block capitalize m-1">&nbsp;{t("phrase.addAsExistingRefs")}</span>
		</button>
	);
}

export function SolutionComponent({ data, show, onSelect }: SolutionComponentProps) {
	const { t } = useTranslation();
	const settings = useSettings();
	const ref = useRef<HTMLDivElement>(null);
	const cardBodyRef = useRef<HTMLDivElement>(null);
	const handleSelect = () => {
		onSelect();
		setTimeout(() => ref.current?.scrollIntoView(), 0);
	};
	const solution = formatSolution(data, settings.precision);

	const err = data.err.toFixed(settings.precision);

	return (
		<div className={"card mt-3 " + (show ? "" : "d-sm-none")} style={{ overflow: "hidden" }}>
			<div className="card-header d-none d-sm-block">
				<div className="row align-items-center gx-1 gy-2">
					<div className="col-auto">
						<Exact err={data.err} />&nbsp;<span className="capitalize">{t("phrase.solution")} {solution},</span>
					</div>
					<div className="col-auto">{t("phrase.error")} {err},</div>
					<div className="col-auto">rank {data.rank}</div>
					<div className="col d-none d-md-block text-end" style={{ flex: "1 0 max-content" }}>
						<AddButton data={data} />
						<ExportButton cardBodyRef={cardBodyRef} solution={data} />
					</div>
				</div>
			</div>
			{show ?
				<div ref={ref} className="card-header d-sm-none text-bg-primary">
					<div className="row align-items-center gx-1">
						<div className="col-auto">
							<Exact err={data.err} />&nbsp;<span className="capitalize">{t("phrase.solution")} {solution},</span>
						</div>
						<div className="col-auto">{t("phrase.error")} {err},</div>
						<div className="col-auto">rank {data.rank}</div>
					</div>
				</div> :
				<div ref={ref} className="card-header d-sm-none" onClick={handleSelect} style={{ cursor: "pointer" }}>
					<div className="row gx-0 justify-content-center align-items-top">
						<div className="col solution-preview" style={{ flex: "0 1 9rem" }}>
							<Diagram
								zoom={DIAGRAM_ZOOM}
								data={data.diagrams[data.diagrams.length - 1]}
								padding={DIAGRAM_PADDING}
							/>
						</div>
						<div className="col mb-2 ps-3 mt-2" style={{ flex: "1 0 8rem" }}>
							<div>{solution}</div>
							<div>{t("phrase.error")} {err}</div>
							<div>rank {data.rank}</div>
						</div>
					</div>
				</div>
			}

			<div ref={cardBodyRef} className={"card-body " + (show ? "" : "d-none")}>
				{data.steps.length == 0 &&
					<div className="row justify-content-center">
						<div className="col" style={{ flex: `0 1 ${DIAGRAM_SIZE}` }}>
							<Diagram data={data.diagrams[0]} last={true} padding={DIAGRAM_PADDING} />
						</div>
						<div className="col p-2" style={{ flex: `1 1 ${DIAGRAM_SIZE}` }}></div>
					</div>
				}
				<div className="row">
					{data.steps.map((step, i) =>
						<div className="col-12 col-md-4 mb-sm-3" key={i}>
							<div className="row justify-content-center">
								<div className="col" style={{ flex: `0 1 ${DIAGRAM_SIZE}` }}>
									<Diagram
										lightbox={true}
										zoom={DIAGRAM_ZOOM}
										data={data.diagrams[i]}
										last={i == data.steps.length - 1}
										padding={DIAGRAM_PADDING}
									/>
								</div>
								<div className="col p-2" style={{ flex: `1 1 ${DIAGRAM_SIZE}` }}>
									<ol start={i + 1}>
										<StepComponent data={step} last={i == data.steps.length - 1} />
									</ol>
								</div>
							</div>
						</div>
					)}
				</div>
				<div className="text-end d-md-none mt-2">
					<AddButton data={data} />
					<ExportButton cardBodyRef={cardBodyRef} solution={data} />
				</div>
			</div>
		</div>
	);
}
